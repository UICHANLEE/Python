# Data structure and Algorithm 

## Code environment

```
conda create -n dssa python=3.7
conda install seaborn jupyter pandas
conda activate dssa
```